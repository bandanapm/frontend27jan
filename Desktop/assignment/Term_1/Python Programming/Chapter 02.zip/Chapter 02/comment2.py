print('Kate Austen')           # Name
print('123 Full Circle Drive') # Street address
print('Asheville, NC 28899')   # City, state, and ZIP
